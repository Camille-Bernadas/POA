class Agent extends Element {

	constructor(x, y, board) {
		super(x, y);
		this.board = board
    this.move(0,0)
	}

	initialiser(x) {
		super.initialiser(x, y, "img/agent.png");
	}

	move(x, y){
      this.board.grid[this.x][this.y] = EMPTY;
      let newX = this.x+x;
      let newY = this.y+y;

      //Out of bound
      if(newX < 0 || newX >= this.board.x || newY < 0 || newY >= this.board.y) {
        return;
      }

      //Movable
      if(this.board.grid[newX][newY] == EMPTY || this.board.grid[newX][newY] == GOAL) {
        this.x += x;
        this.y += y;
      }

      if(this.board.grid[newX][newY] == GOAL) {
        alert("YOU WON");
        restart();
      }

      //Box handling
      if(this.board.grid[newX][newY] == BOX) {
        if(this.board.grid[newX+x][newY+y] == EMPTY) {
          this.board.grid[newX][newY] = EMPTY;
          this.board.grid[newX+x][newY+y] = BOX;
        }
      }

      this.board.grid[this.x][this.y] = PLAYER;
      this.board.updateBoard(this.board.grid);
      console.log(this.x + "," + this.y);
      return;
    }

    interact(){
      //Interactable
      for(let i = this.x-1; i<=this.x+1; i++) {
          for(let j = this.y-1; j<=this.y+1; j++) {
              if(i >= 0 && i < this.board.x && j >= 0 && j < this.board.y) {
                  if(this.board.grid[i][j] == BUTTON_OFF) {
                      this.board.grid[i][j] = BUTTON_ON;
                      this.board.updateBoard(this.board.grid);
                  }
                  else if(this.board.grid[i][j] == BUTTON_ON) {
                      this.board.grid[i][j] = BUTTON_OFF;
                      this.board.updateBoard(this.board.grid);
                  }
              }
          }
      }
      return;
    }

}