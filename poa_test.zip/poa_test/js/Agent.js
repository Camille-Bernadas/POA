class Agent extends Element {

	constructor(x, y) {
		super(x, y, "personnage");
		this.score = 200;
	}

	initialiser(x) {
		super.initialiser(x, y, "img/personnage.png");
		this.score = 200;
	}

	move(x, y) {
		// TODO
	}

}