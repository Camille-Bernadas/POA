class Box extends Element {

	constructor(x, y) {
		super(x, y, "box");
	}

	initialiser(x, y) {
		super.initialiser(x, y, "img/box.png");
	}

	moveable(x, y) {
		// TODO
	}	

}