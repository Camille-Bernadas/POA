class But extends Element {

	constructor(x) {
		super(x, y, "but");
	}

	initialiser(x) {
		super.initialiser(x, y, "img/but.png");
	}

}