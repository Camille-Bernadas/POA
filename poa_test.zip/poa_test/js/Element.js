class Element {

	constructor(x,y) {
		this.x = x;
		this.y = y;
	}

	initialiser(x, y) {
		this.x = x;
		this.y = y;
		this.placer();
	}

	placer() {
		// TODO
	}

}