window.addEventListener('DOMContentLoaded', (event) => {
    console.log("Document ready");
});

class World {
    constructor(width, height) {
        World.width = width;
        World.height = height;
        World.worldGrid = [...Array(width)].map(e=>Array(height).fill(0));
    }

    static isCaseEmpty(x, y) {
        return World.worldGrid[x][y]==0;
    }

    static createPlayer(agent) {
        let x = agent.x;
        let y = agent.y;
        if(World.isCaseEmpty(x, y)) {
            World.worldGrid[x][y] = agent;
            document.getElementById("world").children[this.width*y + x].id = "player";
        }
    }

    static createWall(wall) {
        let x = wall.x;
        let y = wall.y;
        if(World.isCaseEmpty(x, y)) {
            World.worldGrid[x][y] = wall;
            document.getElementById("world").children[this.width*y + x].classList.add("wall");
        }
    }

    static removeWall(x, y) {
        World.worldGrid[x][y] = 0;
        document.getElementById("world").children[this.width*y + x].classList.remove("wall");
    }

    static createButton(button) {
        let x = button.x;
        let y = button.y;
        if(World.isCaseEmpty(x, y)) {
            World.worldGrid[x][y] = button;
            document.getElementById("world").children[this.width*y + x].classList.add("button");
            document.getElementById("world").children[this.width*y + x].addEventListener("click", () => button.activateButton());
        }
    }

    static createBox(box) {
        let x = box.x;
        let y = box.y;
        if(World.isCaseEmpty(x, y)) {
            World.worldGrid[x][y] = box;
            document.getElementById("world").children[this.width*y + x].classList.add("box");
        }
    }


}

class Agent {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        World.createPlayer(this);
    }
}

class Wall {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        World.createWall(this);
    }
}

class Button {
    constructor(x, y, xDoor, yDoor) {
        this.x = x;
        this.y = y;
        this.xDoor = xDoor;
        this.yDoor = yDoor;
        World.createButton(this);
    }

    activateButton() {
        World.removeWall(this.xDoor, this.yDoor);
    }
}

class Box {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        World.createBox(this);
    }
}

class Goal {
    constructor(x, y) {
        this.x = x;
        this.y = y;
    }
}

height = 4;
width = 4;
//Le monde est statique
new World(height, width);
new Wall(0,0);
new Wall(0,1);
console.log(new Button(1,2,0,1));
new Wall(0,2);
new Wall(0,3);
new Box(1,3);
new Goal(3,3);
new Agent(1,1);
